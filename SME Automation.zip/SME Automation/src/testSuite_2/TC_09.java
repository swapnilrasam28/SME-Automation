package testSuite_2;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import testSuite_1.Config;

public class TC_09 extends Config 
{
	@Test ( priority = 3 )
	public void verifyApplicantDetails() throws IOException, InterruptedException
	{
		driver.navigate().to(homepage);
		
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\customerDetails.properties");
		obj.load(objFile);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("transactionLink"))));
		WebElement transaction = driver.findElement(By.xpath(obj.getProperty("transactionLink")));
		action.moveToElement(transaction).build().perform();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("newLoanExpressEntryLink"))));
		driver.findElement(By.xpath(obj.getProperty("newLoanExpressEntryLink"))).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("prospectNoSearchBox"))));
		
		driver.findElement(By.xpath(obj.getProperty("prospectNoSearchBox"))).sendKeys(prospectNo);
//		driver.findElement(By.xpath(obj.getProperty("prospectNoSearchBox"))).sendKeys("SL1070604");
		driver.findElement(By.xpath(obj.getProperty("goButton"))).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("customerDetailsLink"))));
		WebElement customerDetails = driver.findElement(By.xpath(obj.getProperty("customerDetailsLink")));
		action.moveToElement(customerDetails).build().perform();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("clientDetailsLink"))));
		driver.findElement(By.xpath(obj.getProperty("clientDetailsLink"))).click();
		
		// *** Client Details ***
		driver.switchTo().frame("iframetab"); 
		
		String appName = workbook.getSheetAt(1).getRow(9).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[contains(text(),'"+appName+"')]")).click();
		Thread.sleep(3000);
		
		Select orgType = new Select(driver.findElement(By.xpath(obj.getProperty("orgType"))));
		orgType.selectByVisibleText("COMPANY");
		Thread.sleep(2000);
		
		WebElement DOI = driver.findElement(By.xpath(obj.getProperty("DOI")));
		setDate(driver,"01/01/2005",DOI);
		WebElement DOO = driver.findElement(By.xpath(obj.getProperty("DOO")));
		setDate(driver,"28/05/1993",DOO);
		WebElement DOB = driver.findElement(By.xpath(obj.getProperty("DOB")));
		setDate(driver,"25/06/1993",DOB);
		
		driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_txtContactPersonFname']")).sendKeys("Swapnil");
		driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_txtContactPersonlname']")).sendKeys("Rasam");
		
		driver.findElement(By.xpath(obj.getProperty("saveButton"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Identity Details ***
		driver.findElement(By.xpath(obj.getProperty("identityDetailsTab"))).click();
		driver.findElement(By.xpath("//*[contains(text(),'"+appName+"')]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(obj.getProperty("cin/frnNo"))).sendKeys("123455");
		Select idType = new Select(driver.findElement(By.xpath(obj.getProperty("idType"))));
		idType.selectByVisibleText("REGISTRATION CERTIFICATE");
		
		String mobile = workbook.getSheetAt(1).getRow(37).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("mobileNo"))).sendKeys(mobile);
		driver.findElement(By.xpath(obj.getProperty("idNumber"))).sendKeys("11111");
		
		String emailID = workbook.getSheetAt(1).getRow(38).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("emailID"))).sendKeys(emailID);
		
		driver.findElement(By.xpath(obj.getProperty("saveIdentity"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Address Details ***
		driver.findElement(By.xpath(obj.getProperty("addressDetailsTab"))).click();
		
		driver.findElement(By.xpath("//*[contains(text(),'"+appName+"')]")).click();
		Thread.sleep(1500);
		
		Select addressType = new Select(driver.findElement(By.xpath(obj.getProperty("addressType"))));
		String addType = workbook.getSheetAt(1).getRow(42).getCell(1).getStringCellValue();
		addressType.selectByVisibleText(addType);
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("isMailing"))).click();

		String address1 = workbook.getSheetAt(1).getRow(43).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("address1"))).sendKeys(address1);
		
		String address2 = workbook.getSheetAt(1).getRow(44).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("address2"))).sendKeys(address2);
		
		String address3 = workbook.getSheetAt(1).getRow(45).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("address3"))).sendKeys(address3);
		
		String landmark = workbook.getSheetAt(1).getRow(46).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("landmark"))).sendKeys(landmark);
		
		Select country = new Select(driver.findElement(By.xpath(obj.getProperty("country"))));
		String coun = workbook.getSheetAt(1).getRow(47).getCell(1).getStringCellValue();
		country.selectByVisibleText(coun);
		
		Select state = new Select(driver.findElement(By.xpath(obj.getProperty("state"))));
		String State = workbook.getSheetAt(1).getRow(48).getCell(1).getStringCellValue();
		state.selectByVisibleText(State);
		
		Select city = new Select(driver.findElement(By.xpath(obj.getProperty("city"))));
		String City = workbook.getSheetAt(1).getRow(49).getCell(1).getStringCellValue();
		city.selectByVisibleText(City);
		
		String pincode = workbook.getSheetAt(1).getRow(50).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("pinCode"))).sendKeys(pincode);
		
		Select ownershipType = new Select(driver.findElement(By.xpath(obj.getProperty("ownershipType"))));
		String OwnershipType = workbook.getSheetAt(1).getRow(51).getCell(1).getStringCellValue();
		ownershipType.selectByVisibleText(OwnershipType);
		
		String stayingSinceYears = workbook.getSheetAt(1).getRow(52).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("stayingSinceYears"))).sendKeys(stayingSinceYears);
		
		String stayingSinceMonths = workbook.getSheetAt(1).getRow(53).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("stayingSinceMonths"))).sendKeys(stayingSinceMonths);
		
		String STD = workbook.getSheetAt(1).getRow(54).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("STD"))).sendKeys(STD);
		
		String contactNo = workbook.getSheetAt(1).getRow(54).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("contactNo"))).sendKeys(contactNo);
		
		driver.findElement(By.xpath(obj.getProperty("saveAddress"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Existing Bank loan Details ***
		driver.findElement(By.xpath(obj.getProperty("existingLoanDetailsTab"))).click();
		driver.findElement(By.xpath("//*[contains(text(),'"+appName+"')]")).click();
		Thread.sleep(1500);
		
		try 
		{
			String LoanType = workbook.getSheetAt(1).getRow(59).getCell(1).getStringCellValue();
			Select loanType = new Select(driver.findElement(By.xpath(obj.getProperty("loanType"))));
			loanType.selectByVisibleText(LoanType);
		}
		catch (Exception e) 
		{
			String LoanType = workbook.getSheetAt(1).getRow(59).getCell(1).getStringCellValue();
			Select loanType = new Select(driver.findElement(By.xpath(obj.getProperty("loanType"))));
			loanType.selectByVisibleText(LoanType);
		}
		
		String financierName = workbook.getSheetAt(1).getRow(60).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("financierName"))).sendKeys(financierName);
		
		String LocationHead = workbook.getSheetAt(1).getRow(61).getCell(1).getStringCellValue();
		Select locationHead = new Select(driver.findElement(By.xpath(obj.getProperty("locationHead"))));
		locationHead.selectByVisibleText(LocationHead);
		
		Thread.sleep(500);
		String oriLoanAmnt = workbook.getSheetAt(1).getRow(62).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("oriLoanAmnt"))).sendKeys(oriLoanAmnt,Keys.TAB);
		
		Thread.sleep(500);
		String serTenure = workbook.getSheetAt(1).getRow(64).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("serTenure"))).sendKeys(serTenure,Keys.TAB);
		
		Thread.sleep(500);
		String EMI = workbook.getSheetAt(1).getRow(66).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("EMI"))).sendKeys(EMI,Keys.TAB);
		
		Thread.sleep(500);
		String oriTenure = workbook.getSheetAt(1).getRow(63).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("oriTenure"))).sendKeys(oriTenure,Keys.TAB);
		
		Thread.sleep(500);
		String currentBalOS = workbook.getSheetAt(1).getRow(65).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("currentBalOS"))).sendKeys(currentBalOS,Keys.TAB);

		Thread.sleep(500);
		String loanAccNo = workbook.getSheetAt(1).getRow(67).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("loanAccNo"))).sendKeys(loanAccNo,Keys.TAB);
		Thread.sleep(500);
		
		try
		{
			driver.findElement(By.xpath(obj.getProperty("isActive"))).click();
		}
		catch(StaleElementReferenceException e)
		{
			driver.findElement(By.xpath(obj.getProperty("isActive"))).click();
		}
		
		try
		{
			driver.findElement(By.xpath(obj.getProperty("saveLoan"))).click();
		}
		catch(StaleElementReferenceException e)
		{
			driver.findElement(By.xpath(obj.getProperty("saveLoan"))).click();
		}	
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Bank Details ***
		driver.findElement(By.xpath(obj.getProperty("bankDetailsTab"))).click();
		driver.findElement(By.xpath("//*[contains(text(),'"+appName+"')]")).click();
		Thread.sleep(1500);
		
		driver.findElement(By.xpath(obj.getProperty("isPrimary"))).click();
		
		driver.findElement(By.xpath(obj.getProperty("bankCode"))).sendKeys("hdfc");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[contains(text(),'240-HDFC BANK LTD')]")).click();
		
		driver.findElement(By.xpath(obj.getProperty("branchCode"))).sendKeys("029400");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[contains(text(),'029400-HDFC BAN LTD.,THANE W,(TNW)-400240029')]")).click();
		
		driver.findElement(By.xpath(obj.getProperty("IFSCCode"))).sendKeys("HDFC0004051");
		driver.findElement(By.xpath(obj.getProperty("accNo"))).sendKeys("405101511230");
		
		Select accType = new Select(driver.findElement(By.xpath(obj.getProperty("accType"))));
		accType.selectByVisibleText("10 - Saving Account");
		
		driver.findElement(By.xpath(obj.getProperty("noOfCheqReturned"))).sendKeys("0");
		
		driver.findElement(By.xpath(obj.getProperty("saveBank"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		// *** Reference Details ***
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("referenceDetailsTab"))).click();
		driver.findElement(By.xpath("//*[contains(text(),'"+appName+"')]")).click();
		Thread.sleep(2000);
		
		driver.switchTo().frame("tblClientDetails_tbRefernces_ireferences");
		String RefName = workbook.getSheetAt(1).getRow(71).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("refName"))).sendKeys(RefName);
		
		String RefRelationWithApplicant = workbook.getSheetAt(1).getRow(72).getCell(1).getStringCellValue();
		Select refRelationWithApplicant = new Select(driver.findElement(By.xpath(obj.getProperty("refRelationWithApplicant"))));
		refRelationWithApplicant.selectByVisibleText(RefRelationWithApplicant);
		
		String RefAddress1 = workbook.getSheetAt(1).getRow(73).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("refAddress1"))).sendKeys(RefAddress1);
		
		String RefpinCode = workbook.getSheetAt(1).getRow(74).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("refpinCode"))).sendKeys(RefpinCode);
		
		String RefCountry = workbook.getSheetAt(1).getRow(75).getCell(1).getStringCellValue();
		Select refCountry = new Select(driver.findElement(By.xpath(obj.getProperty("refCountry"))));
		refCountry.selectByVisibleText(RefCountry);
		
		String RefState = workbook.getSheetAt(1).getRow(76).getCell(1).getStringCellValue();
		Select refState = new Select(driver.findElement(By.xpath(obj.getProperty("refState"))));
		refState.selectByVisibleText(RefState);
		
		String RefCity = workbook.getSheetAt(1).getRow(77).getCell(1).getStringCellValue();
		Select refCity = new Select(driver.findElement(By.xpath(obj.getProperty("refCity"))));
		refCity.selectByVisibleText(RefCity);
		
		String RefMobile = workbook.getSheetAt(1).getRow(78).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("refMobile"))).sendKeys(RefMobile);
		
		String RefPhone = workbook.getSheetAt(1).getRow(79).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("refPhone"))).sendKeys(RefPhone);
		
		driver.findElement(By.xpath(obj.getProperty("saveRef"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		Thread.sleep(1000);
		
		RefName = workbook.getSheetAt(1).getRow(71).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("refName"))).sendKeys(RefName);
		
		RefRelationWithApplicant = workbook.getSheetAt(1).getRow(72).getCell(2).getStringCellValue();
		refRelationWithApplicant = new Select(driver.findElement(By.xpath(obj.getProperty("refRelationWithApplicant"))));
		refRelationWithApplicant.selectByVisibleText(RefRelationWithApplicant);
		
		RefAddress1 = workbook.getSheetAt(1).getRow(73).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("refAddress1"))).sendKeys(RefAddress1);
		
		RefpinCode = workbook.getSheetAt(1).getRow(74).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("refpinCode"))).sendKeys(RefpinCode);
		
		RefCountry = workbook.getSheetAt(1).getRow(75).getCell(2).getStringCellValue();
		refCountry = new Select(driver.findElement(By.xpath(obj.getProperty("refCountry"))));
		refCountry.selectByVisibleText(RefCountry);
		
		RefState = workbook.getSheetAt(1).getRow(76).getCell(2).getStringCellValue();
		refState = new Select(driver.findElement(By.xpath(obj.getProperty("refState"))));
		refState.selectByVisibleText(RefState);
		
		RefCity = workbook.getSheetAt(1).getRow(77).getCell(2).getStringCellValue();
		refCity = new Select(driver.findElement(By.xpath(obj.getProperty("refCity"))));
		refCity.selectByVisibleText(RefCity);
		
		RefMobile = workbook.getSheetAt(1).getRow(78).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("refMobile"))).sendKeys(RefMobile);
		
		RefPhone = workbook.getSheetAt(1).getRow(79).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("refPhone"))).sendKeys(RefPhone);
		
		driver.findElement(By.xpath(obj.getProperty("saveRef"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		System.out.println("Applicant Details Data Entry Completed");
	}
}