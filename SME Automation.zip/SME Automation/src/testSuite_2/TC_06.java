package testSuite_2;

import testSuite_1.Config;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.expectThrows;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

@SuppressWarnings("unused")
public class TC_06 extends Config
{
	@Test ( priority = 0) 
	public void verifyIMDDetails() throws IOException, InterruptedException 
	{
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\newLoanEntry.properties");
		obj.load(objFile);

		Thread.sleep(2000);
		
		Assert.assertEquals(obj.getProperty("url"), "http://ttavatar.iifl.in/SMELoan/PreloginEntry.aspx");
		
		driver.findElement(By.xpath(obj.getProperty("preLoginDetailsSubmitBtn"))).click();
		Alert alert = driver.switchTo().alert();
		System.out.println("Alert Message for clicking submit button without filling any details: " +alert.getText());
		alert.accept();
	}
	
	
}
