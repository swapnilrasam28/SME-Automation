package testSuite_2;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import testSuite_1.Config;

public class TC_07 extends Config
{
	@Test ( priority = 1) 
	public void verifyCorrectIMDDetails() throws IOException, InterruptedException 
	{
		Thread.sleep(2000);
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\newLoanEntry.properties");
		obj.load(objFile);
		
		Thread.sleep(2000);
		
		Assert.assertEquals(obj.getProperty("url"), "http://ttavatar.iifl.in/SMELoan/PreloginEntry.aspx");
		
		String chequeNo = workbook.getSheetAt(1).getRow(2).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("chequeDDNo"))).sendKeys(chequeNo);
		
		String imdAmount = workbook.getSheetAt(1).getRow(3).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("imdAmount"))).sendKeys(imdAmount);
		
		String bankName = workbook.getSheetAt(1).getRow(4).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("bankName"))).sendKeys(bankName);
		
		driver.findElement(By.xpath(obj.getProperty("bankNameSearch"))).click();
		
		String parentWindow = driver.getWindowHandle();
		for(String childWindow : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow);
		}
		driver.findElement(By.xpath("//*[@id='grdVendor_lnkVendor_1']")).click();
		driver.switchTo().window(parentWindow);
		
		driver.findElement(By.xpath(obj.getProperty("preLoginDetailsMenu"))).click();
		
		String RM = workbook.getSheetAt(1).getRow(11).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("RM"))).sendKeys(RM);
		
		driver.findElement(By.xpath(obj.getProperty("RMSearch"))).click();
		
		parentWindow = driver.getWindowHandle();
		for(String childWindow : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow);
		}
		driver.findElement(By.xpath("//*[@id='grdVendor_lnkVendor_0']")).click();
		driver.switchTo().window(parentWindow);
		
		String DSAName = workbook.getSheetAt(1).getRow(14).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("DSAName"))).sendKeys(DSAName);
		
		driver.findElement(By.xpath(obj.getProperty("DSANameSearch"))).click();
		
		parentWindow = driver.getWindowHandle();
		for(String childWindow : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow);
		}
		driver.findElement(By.xpath("//*[@id='grdVendor_lnkVendor_0']")).click();
		driver.switchTo().window(parentWindow);
		
		try
		{
			Select state = new Select(driver.findElement(By.xpath(obj.getProperty("state"))));
			state.selectByVisibleText("MAHARASHTRA");
		}
		catch (StaleElementReferenceException e)
		{
			Select state = new Select(driver.findElement(By.xpath(obj.getProperty("state"))));
			state.selectByVisibleText("MAHARASHTRA");
		}
		
		try
		{
			Select location = new Select(driver.findElement(By.xpath(obj.getProperty("location"))));
			location.selectByVisibleText("THANE");
		}
		catch (StaleElementReferenceException e)
		{
			Select location = new Select(driver.findElement(By.xpath(obj.getProperty("location"))));
			location.selectByVisibleText("THANE");
		}
		
		Select branch = new Select(driver.findElement(By.xpath(obj.getProperty("branch"))));
		branch.selectByVisibleText("THANE-IIFL HOUSE");
		
		Select product = new Select(driver.findElement(By.xpath(obj.getProperty("product"))));
		product.selectByVisibleText("SME IIFL");
		
		driver.findElement(By.xpath(obj.getProperty("organisation"))).click();
		String panNumber = workbook.getSheetAt(1).getRow(8).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("panNumber"))).sendKeys(panNumber);
		
		Thread.sleep(1000);
		String loanAmount = workbook.getSheetAt(1).getRow(12).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("loanAmount"))).sendKeys(loanAmount);
		
		String tenure = workbook.getSheetAt(1).getRow(13).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("tenure"))).sendKeys(tenure);
		
		Select source = new Select(driver.findElement(By.xpath(obj.getProperty("source"))));
		source.selectByVisibleText("WALKIN");
		
		Select loanPurpose = new Select(driver.findElement(By.xpath(obj.getProperty("loanPurpose"))));
		loanPurpose.selectByVisibleText("Asset Purchase");
		
		Select segment = new Select(driver.findElement(By.xpath(obj.getProperty("segment"))));
		segment.selectByVisibleText("Manufacturing");
		
		String contactNo = workbook.getSheetAt(1).getRow(10).getCell(1).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("contactNo"))).sendKeys(contactNo);
		
		String entityName = workbook.getSheetAt(1).getRow(9).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("entityName"))).sendKeys(entityName);
		driver.findElement(By.xpath(obj.getProperty("entityName"))).clear();
		driver.findElement(By.xpath(obj.getProperty("entityName"))).sendKeys(entityName);
		
		driver.findElement(By.xpath(obj.getProperty("preLoginDetailsSubmitBtn"))).click();
		
		wait.until(ExpectedConditions.alertIsPresent());
		Alert alert = driver.switchTo().alert();
		String text = alert.getText();
		alert.accept();
		System.out.println("Alert Text is: " +text);
		
		prospectNo = text.substring(12, 21);
		System.out.println("Prospect Number is: " +prospectNo);
		driver.switchTo().defaultContent();
	}
}