package testSuite_2;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import testSuite_1.Config;

public class TC_10 extends Config 
{
	@SuppressWarnings("deprecation")
	@Test ( priority = 4 )
	public void verifyCoApplicantDetails() throws IOException, InterruptedException 
	{
		driver.navigate().to(homepage);
		
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\customerDetails.properties");
		obj.load(objFile);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("transactionLink"))));
		WebElement transaction = driver.findElement(By.xpath(obj.getProperty("transactionLink")));
		action.moveToElement(transaction).build().perform();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("newLoanExpressEntryLink"))));
		driver.findElement(By.xpath(obj.getProperty("newLoanExpressEntryLink"))).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("prospectNoSearchBox"))));
		
		driver.findElement(By.xpath(obj.getProperty("prospectNoSearchBox"))).sendKeys(prospectNo);
//		driver.findElement(By.xpath(obj.getProperty("prospectNoSearchBox"))).sendKeys("SL1070604");
		driver.findElement(By.xpath(obj.getProperty("goButton"))).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("customerDetailsLink"))));
		WebElement customerDetails = driver.findElement(By.xpath(obj.getProperty("customerDetailsLink")));
		action.moveToElement(customerDetails).build().perform();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("clientDetailsLink"))));
		driver.findElement(By.xpath(obj.getProperty("clientDetailsLink"))).click();
		
		// *** Client Details ***
		
		driver.switchTo().frame("iframetab");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("applicantType"))));
		Select applicantType = new Select(driver.findElement(By.xpath(obj.getProperty("applicantType"))));
		applicantType.selectByVisibleText("COBORROWER");
		
		wait.until(ExpectedConditions.textToBePresentInElement(By.xpath(obj.getProperty("applicantName")), "Select Applicant"));
		Select applicantName = new Select(driver.findElement(By.xpath(obj.getProperty("applicantName"))));
		applicantName.selectByVisibleText("ADD NEW..");
		Thread.sleep(2000);
		
		wait.until(ExpectedConditions.textToBePresentInElement(By.xpath(obj.getProperty("title")), "Select Title"));
		String Title = workbook.getSheetAt(1).getRow(20).getCell(2).getStringCellValue();
		Select title = new Select(driver.findElement(By.xpath(obj.getProperty("title"))));
		title.selectByVisibleText(Title);
		
		String relation = workbook.getSheetAt(1).getRow(21).getCell(2).getStringCellValue();
		Select Relation = new Select(driver.findElement(By.xpath(obj.getProperty("relationWithApplicant"))));
		Relation.selectByVisibleText(relation);
		
		try
		{
			String fName = workbook.getSheetAt(1).getRow(22).getCell(2).getStringCellValue();
			driver.findElement(By.xpath(obj.getProperty("firstName"))).sendKeys(fName);
		}
		catch (StaleElementReferenceException e)
		{
			String fName = workbook.getSheetAt(1).getRow(22).getCell(2).getStringCellValue();
			driver.findElement(By.xpath(obj.getProperty("firstName"))).sendKeys(fName);
		}
		
		String mName = workbook.getSheetAt(1).getRow(23).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("middleName"))).sendKeys(mName);
		
		String lName = workbook.getSheetAt(1).getRow(24).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("lastName"))).sendKeys(lName);
		
		driver.findElement(By.xpath(obj.getProperty("male"))).click();
//		driver.findElement(By.xpath(obj.getProperty("female"))).click();
		
		String motherMaiden = workbook.getSheetAt(1).getRow(25).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("motherMaidenName"))).sendKeys(motherMaiden);
		
		String fatherguardian = workbook.getSheetAt(1).getRow(26).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("father/guardianName"))).sendKeys(fatherguardian);
		
		WebElement cal= driver.findElement(By.xpath(obj.getProperty("dob")));
		String date = workbook.getSheetAt(1).getRow(27).getCell(2).getStringCellValue();
		Config.setDate(driver,date,cal);
		
		String maritial = workbook.getSheetAt(1).getRow(28).getCell(2).getStringCellValue();
		Select Maritial = new Select(driver.findElement(By.xpath(obj.getProperty("maritialStatus"))));
		Maritial.selectByVisibleText(maritial);
		
		String Qualification = workbook.getSheetAt(1).getRow(30).getCell(2).getStringCellValue();
		Select quali = new Select(driver.findElement(By.xpath(obj.getProperty("qualification"))));
		quali.selectByVisibleText(Qualification);
		
		String Category = workbook.getSheetAt(1).getRow(31).getCell(2).getStringCellValue();
		Select cate = new Select(driver.findElement(By.xpath(obj.getProperty("category"))));
		cate.selectByVisibleText(Category);
		
		driver.findElement(By.xpath(obj.getProperty("noOfDependant"))).sendKeys("0");
		
		driver.findElement(By.xpath(obj.getProperty("saveButton"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Identity Details ***
		driver.findElement(By.xpath(obj.getProperty("identityDetailsTab"))).click();
		
		String coAppfullName = workbook.getSheetAt(1).getRow(24).getCell(11).getStringCellValue();
		System.out.println("Full Name: "+coAppfullName);
		driver.findElement(By.xpath("//*[contains(text(),'"+coAppfullName+"')]")).click();
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(obj.getProperty("panNumber"))).sendKeys("BIHPR9705H");
		try 
		{
			driver.findElement(By.xpath(obj.getProperty("verifyPAN"))).click();
		} 
		catch (StaleElementReferenceException e) 
		{
			driver.findElement(By.xpath(obj.getProperty("verifyPAN"))).click();
		}
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(obj.getProperty("aadharNumber"))).sendKeys("987204864026");
		
		String mobile = workbook.getSheetAt(1).getRow(37).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("mobileNo"))).sendKeys(mobile);
		
		String emailID = workbook.getSheetAt(1).getRow(38).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("emailID"))).sendKeys(emailID);
		
		driver.findElement(By.xpath(obj.getProperty("saveIdentity"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Address Details ***
		driver.findElement(By.xpath(obj.getProperty("addressDetailsTab"))).click();
		
		driver.findElement(By.xpath("//*[contains(text(),'"+coAppfullName+"')]")).click();
		Thread.sleep(3000);
		
		Select addressType = new Select(driver.findElement(By.xpath(obj.getProperty("addressType"))));
		String addType = workbook.getSheetAt(1).getRow(42).getCell(2).getStringCellValue();
		addressType.selectByVisibleText(addType);
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("isMailing"))).click();

		String address1 = workbook.getSheetAt(1).getRow(43).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("address1"))).sendKeys(address1);
		
		String address2 = workbook.getSheetAt(1).getRow(44).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("address2"))).sendKeys(address2);
		
		String address3 = workbook.getSheetAt(1).getRow(45).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("address3"))).sendKeys(address3);
		
		String landmark = workbook.getSheetAt(1).getRow(46).getCell(2).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("landmark"))).sendKeys(landmark);
		
		Select country = new Select(driver.findElement(By.xpath(obj.getProperty("country"))));
		String coun = workbook.getSheetAt(1).getRow(47).getCell(2).getStringCellValue();
		country.selectByVisibleText(coun);
		
		Select state = new Select(driver.findElement(By.xpath(obj.getProperty("state"))));
		String State = workbook.getSheetAt(1).getRow(48).getCell(2).getStringCellValue();
		state.selectByVisibleText(State);
		
		Select city = new Select(driver.findElement(By.xpath(obj.getProperty("city"))));
		String City = workbook.getSheetAt(1).getRow(49).getCell(2).getStringCellValue();
		city.selectByVisibleText(City);
		
		String pincode = workbook.getSheetAt(1).getRow(50).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("pinCode"))).sendKeys(pincode);
		
		Select ownershipType = new Select(driver.findElement(By.xpath(obj.getProperty("ownershipType"))));
		String OwnershipType = workbook.getSheetAt(1).getRow(51).getCell(2).getStringCellValue();
		ownershipType.selectByVisibleText(OwnershipType);
		
		String stayingSinceYears = workbook.getSheetAt(1).getRow(52).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("stayingSinceYears"))).sendKeys(stayingSinceYears);
		
		String stayingSinceMonths = workbook.getSheetAt(1).getRow(53).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("stayingSinceMonths"))).sendKeys(stayingSinceMonths);
		
		String STD = workbook.getSheetAt(1).getRow(54).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("STD"))).sendKeys(STD);
		
		String contactNo = workbook.getSheetAt(1).getRow(54).getCell(2).getRawValue();
		driver.findElement(By.xpath(obj.getProperty("contactNo"))).sendKeys(contactNo);
		
		driver.findElement(By.xpath(obj.getProperty("saveAddress"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
		wait.until(ExpectedConditions.alertIsPresent());
		alert = driver.switchTo().alert();
		System.out.println("Second Alert after clicking on save button: " +alert.getText());
		alert.accept();
		
		// *** Bank Details ***
		driver.findElement(By.xpath(obj.getProperty("bankDetailsTab"))).click();
		driver.findElement(By.xpath("//*[contains(text(),'"+coAppfullName+"')]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(obj.getProperty("isPrimary"))).click();
		
		driver.findElement(By.xpath(obj.getProperty("bankCode"))).sendKeys("1867");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[contains(text(),'1867-ICICI BAnk Ltd')]")).click();
		
		driver.findElement(By.xpath(obj.getProperty("branchCode"))).sendKeys("229");
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[contains(text(),'229- GROUND FLOOR,HOTEL VISWANATH BIDGS,NEAR SILVASSA CHAR RASTASILVASSA-396229111')]")).click();
		
		driver.findElement(By.xpath(obj.getProperty("IFSCCode"))).sendKeys("ICIC0001044");
		driver.findElement(By.xpath(obj.getProperty("accNo"))).sendKeys("104401511228");
		
		Select accType = new Select(driver.findElement(By.xpath(obj.getProperty("accType"))));
		accType.selectByVisibleText("10 - Saving Account");
		
		driver.findElement(By.xpath(obj.getProperty("noOfCheqReturned"))).sendKeys("0");
		
		driver.findElement(By.xpath(obj.getProperty("saveBank"))).click();
		
		alert = driver.switchTo().alert();
		System.out.println("Alert on click of save button: " +alert.getText());
		alert.accept();
		
	}
}
