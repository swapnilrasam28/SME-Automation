package testSuite_2;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import testSuite_1.Config;

public class TC_08 extends Config
{
	@Test ( priority = 2)
	public void sourcingDetails() throws InterruptedException, IOException
	{
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\preLogin.properties");
		obj.load(objFile);
		
		Thread.sleep(2000);
		driver.navigate().to("http://ttavatar.iifl.in/SMELoan/Welcome.aspx");
		driver.findElement(By.xpath(obj.getProperty("preLoginLink"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[contains(text(),'"+prospectNo+"')]/preceding::*[contains(text(),'Move To Los')][1]")).click();
//		driver.findElement(By.xpath("//*[contains(text(),'SL1070613')]/preceding::*[contains(text(),'Move To Los')][1]")).click();
		Thread.sleep(2000);
		
		driver.switchTo().frame("iframetab");
		Thread.sleep(2000);
		
		try
		{
			Select scheme = new Select(driver.findElement(By.xpath(obj.getProperty("scheme"))));
			String Scheme = workbook.getSheetAt(2).getRow(3).getCell(1).getStringCellValue();
			scheme.selectByVisibleText(Scheme);
		}
		catch (StaleElementReferenceException e)
		{
			Select scheme = new Select(driver.findElement(By.xpath(obj.getProperty("scheme"))));
			String Scheme = workbook.getSheetAt(2).getRow(3).getCell(1).getStringCellValue();
			scheme.selectByVisibleText(Scheme);
		}
		
		Select loanType = new Select(driver.findElement(By.xpath(obj.getProperty("loanType"))));
		String LoanType = workbook.getSheetAt(2).getRow(4).getCell(1).getStringCellValue();
		loanType.selectByVisibleText(LoanType);
		
		Select creditHub = new Select(driver.findElement(By.xpath(obj.getProperty("creditHub"))));
		String CreditHub = workbook.getSheetAt(2).getRow(5).getCell(1).getStringCellValue();
		creditHub.selectByVisibleText(CreditHub);
		
		Select city = new Select(driver.findElement(By.xpath(obj.getProperty("city"))));
		String City = workbook.getSheetAt(2).getRow(6).getCell(1).getStringCellValue();
		city.selectByVisibleText(City);
		
		Select branch = new Select(driver.findElement(By.xpath(obj.getProperty("branch"))));
		String Branch = workbook.getSheetAt(2).getRow(7).getCell(1).getStringCellValue();
		branch.selectByVisibleText(Branch);
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("salesExecutive"))).sendKeys("C145427-Ashish Tiwari");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li/div[contains(text(),'C145427-Ashish Tiwari')]")).click();
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("relationshipManager"))).sendKeys("C142657-Ashish Purshottam Mainkar");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li/div[contains(text(),'C142657-Ashish Purshottam Mainkar')]")).click();
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("processor"))).sendKeys("C129443-Anand Jaiprakash Rathi");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li/div[contains(text(),'C129443-Anand Jaiprakash Rathi')]")).click();
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("locationHeadName"))).sendKeys("C145716-Dhaval Narendrakumar Panchal");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li/div[contains(text(),'C145716-Dhaval Narendrakumar Panchal')]")).click();
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(obj.getProperty("creditManager"))).sendKeys("C144375-Mrunalini Ashok Derle");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li/div[contains(text(),'C144375-Mrunalini Ashok Derle')]")).click();
		
		driver.findElement(By.xpath(obj.getProperty("sourcingDetailsSaveBtn"))).click();
		
		Alert alert = driver.switchTo().alert();
		
		System.out.println("Alert on click of save button: "+alert.getText());
		alert.accept();
		wait.until(ExpectedConditions.alertIsPresent());
		
		alert = driver.switchTo().alert();
		System.out.println("Second alert after accepting first alert: "+alert.getText());
		alert.accept();
	}
}
