package testSuite_1;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_04 extends Config
{
	@Test (priority = 5)
	public void validateViewTop10Entry() throws IOException 
	{
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\Welcome.properties");
		obj.load(objFile);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("veiwTop10Entry"))));
		driver.findElement(By.xpath(obj.getProperty("veiwTop10Entry"))).click();

		wait.until(ExpectedConditions.urlMatches("http://ttavatar.iifl.in/SMELoan/Welcome.aspx"));
		Assert.assertEquals("http://ttavatar.iifl.in/SMELoan/Welcome.aspx", driver.getCurrentUrl());
		
		isPresent = driver.findElements(By.xpath(obj.getProperty("applicantDetailsContainer"))).size() > 0;
		if(isPresent == true)
			System.out.println("Validate View Top 10 Entry: User is redirected to correct page");
		else
			System.out.println("Validate View Top 10 Entry: User is redirected to incorrect page");
	}
}
