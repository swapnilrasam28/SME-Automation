package testSuite_1;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

public class TC_03 extends Config
{
	@Test (priority = 4) 
	public void logout() throws InterruptedException, IOException 
	{
		action = new Actions(driver);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='lblUserName']")));
		WebElement welcome = driver.findElement(By.xpath("//*[@id='lblUserName']"));
		action.moveToElement(welcome).build().perform();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnLogOut']")));
		
		WebElement logOut = driver.findElement(By.xpath(obj.getProperty("Logout")));
		getScreenshot();
		logOut.click();
		System.out.println("Verifying Logout: Logging out Sucessfully");
		
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();
	}	
}
