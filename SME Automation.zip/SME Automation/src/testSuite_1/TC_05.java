package testSuite_1;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_05 extends Config 
{
	@Test ( priority = 6)
	public void clickOnNewLoanEntry() throws IOException 
	{
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\Welcome.properties");
		obj.load(objFile);
		
		driver.navigate().to(homepage);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("transaction"))));
		WebElement trans = driver.findElement(By.xpath(obj.getProperty("transaction")));
		action.moveToElement(trans).build().perform();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(obj.getProperty("newLoanEntry"))));
		WebElement newEntry = driver.findElement(By.xpath(obj.getProperty("newLoanEntry")));
		newEntry.click();
		
		wait.until(ExpectedConditions.urlMatches("http://ttavatar.iifl.in/SMELoan/PreloginEntry.aspx"));
		Assert.assertEquals("http://ttavatar.iifl.in/SMELoan/PreloginEntry.aspx", driver.getCurrentUrl());
		
		isPresent = driver.findElements(By.xpath(obj.getProperty("IMDTab"))).size() > 0;
		if(isPresent == true)
			System.out.println("Click on New Loan Entry: User is redirected to correct page");
		else
			System.out.println("Click on New Loan Entry: User is redirected to incorrect page");
	}
}
