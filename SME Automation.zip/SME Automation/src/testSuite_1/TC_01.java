package testSuite_1;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

public class TC_01 extends Config 
{
	@Test ( priority = 0 )
	public void invalidUsername() throws IOException 
	{
		String userName = workbook.getSheetAt(0).getRow(2).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("Username"))).sendKeys(userName);
		driver.findElement(By.xpath(obj.getProperty("Password"))).click();
//		getScreenshot();
		wait.until(ExpectedConditions.alertIsPresent());		
		Alert alert = driver.switchTo().alert();
		System.out.println("User rights verification: "+alert.getText());
		alert.accept();
	}
}
