package testSuite_1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class Config
{
	public static WebDriver driver;
	public static XSSFWorkbook workbook;
	public static WebDriverWait wait;
	public static Properties obj = new Properties();
	public static FileInputStream objFile;
	public static Actions action;
	public static Alert alert;
	public static String homepage = "http://ttavatar.iifl.in/SMELoan/Welcome_new.aspx"; 
	public static boolean isPresent;
	public JavascriptExecutor jse = (JavascriptExecutor)driver;
	public static String prospectNo;
	
	public static String timestamp() 
	{
		return new SimpleDateFormat("YYYY-MM-dd HH-MM-SS").format(Calendar.getInstance().getTime());
	}
	
	public static String date()
	{
		Calendar.getInstance();
		return new SimpleDateFormat("YYY-MM-dd").format(Calendar.DATE);
	}
	
	public static void getScreenshot() throws IOException 
	{
		File scr=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    File dest= new File("E://SME//" +date()+ "// " +timestamp()+ ".png");
	    FileUtils.copyFile(scr, dest);
	}
	
	
	
	public static void setDate(WebDriver driver, String date, WebElement calLocator)
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		String script= "arguments[0].setAttribute('value','"+date+"');";
		jse.executeScript(script, calLocator);
	}
	
	@BeforeSuite
	public void testSetup() throws FileNotFoundException, IOException
	{
		
		workbook = new XSSFWorkbook(new FileInputStream(System.getProperty("user.dir")+ "/Test Data/AppTestData.xlsx"));
		objFile = new FileInputStream(System.getProperty("user.dir")+ "\\src\\objectRepository\\Login.properties");
		obj.load(objFile);
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		action = new Actions(driver);
		wait = new WebDriverWait(driver, 20);
//		.until(webDriver->((JavascriptExecutor)webDriver).executeScript("return document.readyState").equals("complete");
		String baseURL = "http://ttavatar.iifl.in/smeloan/LoginForm.aspx";
		driver.navigate().to(baseURL);
		driver.manage().window().maximize();
		getScreenshot();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	}

	@AfterSuite
	public void endSession() throws InterruptedException 
	{
		Thread.sleep(2000);
		String skip = "Skip Test";
		if (skip.equalsIgnoreCase("Skip Test"))
			throw new SkipException("Skipping this exception");
		else
			Thread.sleep(2000);
		System.out.println("Shutting Down Browser");
		driver.close();
	}
}
