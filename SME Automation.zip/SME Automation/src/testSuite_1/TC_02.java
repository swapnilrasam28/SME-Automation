package testSuite_1;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_02 extends Config
{
	@Test ( priority = 1 )
	public void verifyTitle() throws IOException
	{
		String actualTitle = "SME Finance";
		String expectedTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle);
	}
		
	@SuppressWarnings("deprecation")
	@Test ( priority = 2 )
	public void login() throws IOException, InterruptedException
	{
		driver.navigate().refresh();
		
		driver.findElement(By.xpath(obj.getProperty("Username"))).click();
		String userName = workbook.getSheetAt(0).getRow(0).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("Username"))).sendKeys(userName);
		getScreenshot();
		
		driver.findElement(By.xpath(obj.getProperty("Password"))).click();
		wait.until(ExpectedConditions.textToBePresentInElement(By.xpath("//*[@id='drpdnCompany']"), "SME"));
		String password = workbook.getSheetAt(0).getRow(1).getCell(1).getStringCellValue();
		driver.findElement(By.xpath(obj.getProperty("Password"))).sendKeys(password);
		getScreenshot();
		
		driver.findElement(By.xpath(obj.getProperty("Login"))).click();
		System.out.println("Verify Login: Login sucessful");
	}

	@Test ( priority = 3 )
	public void validatePageAfterLogin() throws InterruptedException, IOException
	{
		Thread.sleep(1000);
		System.out.println("Verifying page title after login");
		getScreenshot();
		Assert.assertEquals(driver.getTitle(), "IIFL SME");
	}
}
